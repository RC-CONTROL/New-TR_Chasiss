#include "time.h"

void wait(uint32_t n)
{
	do
	{
		n--;
	}while(n);
}
